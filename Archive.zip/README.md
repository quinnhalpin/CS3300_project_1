# CS3300_project_1
By: Quinn Halpin, Weston Forster, and Sofie Cornelis
<n>This project is a static visualization of the net migration of people in middle eastern countries in 2015.
